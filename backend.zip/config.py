import os
from dotenv import load_dotenv

load_dotenv()

# API Keys
NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY")
NEWS_API_KEY = os.getenv("NEWS_API_KEY")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# URLs & Endpoints
NVIDIA_BASE_URL = os.getenv("NVIDIA_BASE_URL")
MODEL_NAME = os.getenv("MODEL_NAME")
RSS_URL = os.getenv("RSS_URL")

# Paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Detect AWS Elastic Beanstalk (EB) environment or Production mode
IS_PRODUCTION = os.getenv("FLASK_ENV") == "production" or os.path.exists("/var/app/current")

if IS_PRODUCTION:
    # On AWS EB, /tmp is writable, but /var/app/current may have restrictions
    DB_PATH = os.getenv("DB_PATH", "/tmp/creaitr_db")
else:
    DB_PATH = os.getenv("DB_PATH", os.path.join(BASE_DIR, "my_local_db"))

UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")

# MongoDB
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")

# Cloudinary
CLOUDINARY_CLOUD_NAME = os.getenv("CLOUDINARY_CLOUD_NAME")
CLOUDINARY_API_KEY = os.getenv("CLOUDINARY_API_KEY")
CLOUDINARY_API_SECRET = os.getenv("CLOUDINARY_API_SECRET")

# Server
PORT = int(os.getenv("PORT", 5000))

# JWT
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "default-secret-change-me")

# YouTube
YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")

# Google OAuth
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")

# YouTube Analytics OAuth
YOUTUBE_ANALYTICS_REDIRECT_URI = os.getenv(
    "YOUTUBE_ANALYTICS_REDIRECT_URI", "http://localhost:5000/auth/youtube/callback"
)
